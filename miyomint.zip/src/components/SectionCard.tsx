import type { ReactNode, ElementType } from 'react';
import { cn } from '../lib/cn';

type Surface = 'default' | 'frosted' | 'muted';
type Padding = 'none' | 'sm' | 'md' | 'lg';

interface SectionCardProps {
  children: ReactNode;
  className?: string;
  surface?: Surface;
  padding?: Padding;
  as?: ElementType;
}

const surfaceStyles: Record<Surface, string> = {
  default: 'bg-transparent',
  frosted:
    'bg-white/[0.03] border border-white/10 rounded-3xl backdrop-blur-xl shadow-[0_20px_80px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.05)]',
  muted: 'bg-slate-900/50 border border-white/10 rounded-3xl backdrop-blur',
};

const paddingScale: Record<Padding, string> = {
  none: '',
  sm: 'p-4 sm:p-6',
  md: 'p-5 sm:p-7 md:p-8',
  lg: 'p-6 sm:p-8 md:p-10',
};

export default function SectionCard({
  children,
  className,
  surface = 'default',
  padding = 'none',
  as: Tag = 'section',
}: SectionCardProps) {
  return (
    <Tag
      className={cn(
        'block w-full',
        surfaceStyles[surface],
        paddingScale[padding],
        className
      )}
    >
      {children}
    </Tag>
  );
}
