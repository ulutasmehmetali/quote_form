import plumberImg from '@assets/roofing services_1764316007803.webp';
import electricianImg from '@assets/electric_1764315995946.jpg';
import hvacImg from '@assets/hvac_1764316003781.jpg';
import contractorImg from '@assets/remodeling_1764316006112.webp';
import mobileHeroBg from '@assets/generated_images/professional_contractor_at_work.png';

const trustBadges = [
  {
    label: 'Verified Pros',
    desc: 'Background checked',
    icon: (
      <svg className="w-5 h-5 text-sky-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
      </svg>
    ),
  },
  {
    label: 'Fast Quotes',
    desc: 'Within hours',
    icon: (
      <svg className="w-5 h-5 text-sky-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
      </svg>
    ),
  },
  {
    label: 'Local Experts',
    desc: 'In your area',
    icon: (
      <svg className="w-5 h-5 text-sky-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
      </svg>
    ),
  },
];

export default function HeroSection() {
  return (
    <section className="relative overflow-visible">
      <div 
        className="fixed inset-0 lg:hidden pointer-events-none"
        style={{
          backgroundImage: `url(${mobileHeroBg})`,
          backgroundSize: 'auto 50vh',
          backgroundPosition: 'center 10%',
          backgroundRepeat: 'no-repeat',
          zIndex: 0,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#030a14]/40 via-[#030a14]/80 to-[#030a14]"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#030a14]/50 via-transparent to-transparent"></div>
      </div>

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-12 items-center">
        <div className="space-y-3 sm:space-y-4 lg:space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-emerald-500/20 to-sky-500/20 border border-emerald-400/30 backdrop-blur-sm">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
            </span>
            <span className="text-sm font-semibold text-emerald-300 tracking-wide">MIYOMINT</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black leading-[1.1] text-white drop-shadow-lg">
            Find certified<br />
            <span className="bg-gradient-to-r from-sky-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
              home pros
            </span>
            <br />in minutes
          </h1>

          <p className="text-sm sm:text-base lg:text-xl text-slate-200 max-w-lg leading-relaxed drop-shadow-md">
            Describe your project, get matched with certified local professionals, and receive quotes fast.
          </p>

          <div className="flex items-stretch gap-1.5 sm:gap-2">
            {trustBadges.map((badge) => (
              <div
                key={badge.label}
                className="flex-1 flex flex-col items-center justify-center gap-1 sm:gap-1.5 px-1.5 sm:px-2 py-2 sm:py-3 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md text-center"
              >
                <div className="flex items-center justify-center w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-sky-500/10 border border-sky-400/20">
                  <div className="scale-75">{badge.icon}</div>
                </div>
                <div>
                  <p className="text-[10px] sm:text-xs font-semibold text-white">{badge.label}</p>
                  <p className="text-[9px] sm:text-[10px] text-slate-400">{badge.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3 pt-2">
            <div className="flex -space-x-2">
              {[plumberImg, electricianImg, hvacImg].map((img, i) => (
                <div
                  key={i}
                  className="w-8 h-8 rounded-full border-2 border-slate-900 overflow-hidden shadow-lg"
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
            <div>
              <p className="text-xs font-semibold text-white">10,000+ projects completed</p>
              <p className="text-[10px] text-slate-400">Join thousands of happy homeowners</p>
            </div>
          </div>
        </div>

        <div className="relative hidden lg:block">
          <div className="absolute -inset-4 bg-gradient-to-r from-sky-500/20 via-indigo-500/20 to-emerald-500/20 rounded-3xl blur-3xl opacity-50"></div>
          <div className="relative grid grid-cols-2 gap-3 sm:gap-4">
            <div className="space-y-3 sm:space-y-4">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] shadow-2xl">
                <img
                  src={plumberImg}
                  alt="Professional plumber"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3">
                  <span className="px-2 py-1 bg-sky-500/90 text-white text-xs font-semibold rounded-lg">Roofing</span>
                </div>
              </div>
              <div className="relative rounded-2xl overflow-hidden aspect-square shadow-2xl">
                <img
                  src={hvacImg}
                  alt="HVAC technician"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3">
                  <span className="px-2 py-1 bg-emerald-500/90 text-white text-xs font-semibold rounded-lg">HVAC</span>
                </div>
              </div>
            </div>
            <div className="space-y-3 sm:space-y-4 pt-6 sm:pt-8">
              <div className="relative rounded-2xl overflow-hidden aspect-square shadow-2xl">
                <img
                  src={electricianImg}
                  alt="Professional electrician"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3">
                  <span className="px-2 py-1 bg-amber-500/90 text-white text-xs font-semibold rounded-lg">Electrical</span>
                </div>
              </div>
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] shadow-2xl">
                <img
                  src={contractorImg}
                  alt="Home contractor"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3">
                  <span className="px-2 py-1 bg-indigo-500/90 text-white text-xs font-semibold rounded-lg">Remodeling</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials Section - Hidden on mobile to keep form above fold */}
      <div className="hidden lg:block mt-12 lg:mt-16">
        <div className="text-center mb-6">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">Trusted by Homeowners Nationwide</h3>
          <div className="flex items-center justify-center gap-1">
            {[...Array(5)].map((_, i) => (
              <svg key={i} className="w-5 h-5 text-amber-400 fill-current" viewBox="0 0 20 20">
                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
              </svg>
            ))}
            <span className="ml-2 text-sm text-slate-300">4.9/5 from 2,000+ verified reviews</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              name: 'Sarah M.',
              service: 'Roofing Repair',
              rating: 5,
              review: 'Found an amazing roofer within hours! The whole process was seamless and the quality of work exceeded my expectations.',
              badge: 'Verified Homeowner'
            },
            {
              name: 'Michael R.',
              service: 'Electrical Work',
              rating: 5,
              review: 'The electrician was licensed, professional, and fixed everything in one visit. Love how easy this platform makes finding trusted pros!',
              badge: 'Verified Homeowner'
            },
            {
              name: 'Jennifer L.',
              service: 'HVAC Service',
              rating: 5,
              review: 'Quick response, fair pricing, and excellent service. My AC was repaired the same day I submitted my request!',
              badge: 'Verified Homeowner'
            }
          ].map((testimonial, i) => (
            <div key={i} className="group p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/8 hover:border-white/20 transition-all duration-300">
              <div className="flex items-center gap-0.5 mb-2">
                {[...Array(testimonial.rating)].map((_, j) => (
                  <svg key={j} className="w-4 h-4 text-amber-400 fill-current" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                  </svg>
                ))}
              </div>
              <p className="text-sm text-white/90 mb-3 leading-relaxed">"{testimonial.review}"</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-white">{testimonial.name}</p>
                  <p className="text-xs text-slate-400">{testimonial.service}</p>
                </div>
                <div className="px-2 py-1 rounded-lg bg-emerald-500/10 border border-emerald-400/20">
                  <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Certifications - Compact */}
        <div className="mt-8 p-3 rounded-2xl bg-white/5 border border-white/10">
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <div className="flex items-center gap-1.5">
              <div className="w-6 h-6 rounded-lg bg-sky-500/10 border border-sky-400/20 flex items-center justify-center">
                <svg className="w-4 h-4 text-sky-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <span className="text-xs font-medium text-white">Licensed & Insured</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-400/20 flex items-center justify-center">
                <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <span className="text-xs font-medium text-white">Background Checked</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-6 h-6 rounded-lg bg-amber-500/10 border border-amber-400/20 flex items-center justify-center">
                <svg className="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                </svg>
              </div>
              <span className="text-xs font-medium text-white">Top Rated Pros</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
